let grid = [];
let cols = 30;
let rows = 30;
let cellSize = 20;

let sigma0Slider, decaySlider, fSSlider;
let applyButton, undoButton, resetButton;
let history = [];
let iteration = 0;

function setup() {
  createCanvas(cols * cellSize + 220, rows * cellSize);

  // Слайдеры
  sigma0Slider = createSlider(1, 100, 20, 1);
  sigma0Slider.position(cols * cellSize + 20, 30);
  createDiv('sigma0 (пиковое напряжение)').position(cols * cellSize + 20, 5);

  decaySlider = createSlider(0.01, 0.5, 0.25, 0.01);
  decaySlider.position(cols * cellSize + 20, 100);
  createDiv('decay (затухание)').position(cols * cellSize + 20, 75);

  fSSlider = createSlider(0.75, 0.98, 0.95, 0.01);
  fSSlider.position(cols * cellSize + 20, 170);
  createDiv('fS (коэффициент разрушения)').position(cols * cellSize + 20, 145);

  // Кнопки
  applyButton = createButton('Следующий шаг');
  applyButton.position(cols * cellSize + 20, 220);
  applyButton.mousePressed(simulateFracture);

  undoButton = createButton('Шаг назад');
  undoButton.position(cols * cellSize + 20, 260);
  undoButton.mousePressed(undoFracture);

  resetButton = createButton('Сбросить всё');
  resetButton.position(cols * cellSize + 20, 300);
  resetButton.mousePressed(resetGrid);

  initGrid();
}

function initGrid() {
  grid = [];
  for (let y = 0; y < rows; y++) {
    grid[y] = [];
    for (let x = 0; x < cols; x++) {
      grid[y][x] = {
        stress: 0,
        broken: false,
        willBreak: false,
        damage: 0
      };
    }
  }
  history = [];
  iteration = 0;
}

function draw() {
background(255);
  let maxVisualStress = Math.max(...grid.flat().map(cell => cell.stress));

  // Рисуем сетку
  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      let cell = grid[y][x];
      let c = colorForStress(cell.stress, cell.broken, cell.willBreak, cell.damage, maxVisualStress);
      fill(c);
      stroke(cell.broken ? 100 : 200);
      strokeWeight(cell.broken ? 2 : 1);
      rect(x * cellSize, y * cellSize, cellSize, cellSize);
    }
  }

  fill(0);
  noStroke();
  textSize(14);
  text("Итерация: " + iteration, cols * cellSize + 20, 360);
  let brokenCount = grid.flat().filter(cell => cell.broken).length;
  text("Разрушено: " + brokenCount, cols * cellSize + 20, 380);

  textSize(12);
  text("sigma0: " + sigma0Slider.value(), cols * cellSize + 20, 55);
  text("decay: " + decaySlider.value(), cols * cellSize + 20, 125);
  text("fS: " + fSSlider.value(), cols * cellSize + 20, 195);
}

function mousePressed() {
  let x = floor(mouseX / cellSize);
  let y = floor(mouseY / cellSize);
  if (x >= 0 && x < cols && y >= 0 && y < rows) {
    grid[y][x].stress = sigma0Slider.value();
    grid[y][x].broken = false;
    grid[y][x].damage = 0;
  }
}

function simulateFracture() {
  saveState();
  iteration++;

  let decay = decaySlider.value();
  let fS = fSSlider.value();

  let newStress = [];
  for (let y = 0; y < rows; y++) {
    newStress[y] = [];
    for (let x = 0; x < cols; x++) {
      if (grid[y][x].broken) {
        newStress[y][x] = 0;
        continue;
      }

      let totalStress = 0;
      for (let y0 = 0; y0 < rows; y0++) {
        for (let x0 = 0; x0 < cols; x0++) {
          let source = grid[y0][x0];
          if (source.stress > 0 && !source.broken) {
            let d = dist(x, y, x0, y0);
            totalStress += source.stress * exp(-decay * d) / (1 + d * d);
          }
        }
      }

      newStress[y][x] = totalStress;
    }
  }

  let maxStress = 0;
  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      if (!grid[y][x].broken) {
        maxStress = max(maxStress, newStress[y][x]);
      }
    }
  }

  let threshold = fS * maxStress;

  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      let cell = grid[y][x];

      if (cell.broken) {
        cell.willBreak = false;
        continue;
      }

      cell.stress = newStress[y][x];

      if (cell.stress >= threshold) {
        cell.damage += 0.3;
      } else {
        cell.damage = max(0, cell.damage - 0.05);
      }

      let neighbors = getNeighbors(x, y);
      let allBroken = neighbors.length > 0 && neighbors.every(n => n.broken);

      if (cell.damage >= 1 || allBroken) {
        cell.willBreak = true;
      } else {
        cell.willBreak = false;
      }
    }
    }

  // Применить разрушения
  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      if (grid[y][x].willBreak) {
        grid[y][x].broken = true;
        grid[y][x].willBreak = false;
        grid[y][x].damage = 1;
      }
    }
  }
}

function undoFracture() {
  if (history.length > 0) {
    grid = history.pop().map(row =>
      row.map(cell => ({ ...cell }))
    );
    iteration = max(0, iteration - 1);
  }
}

function saveState() {
  if (history.length >= 5) {
    history.shift();
  }
  let snapshot = grid.map(row =>
    row.map(cell => ({ ...cell }))
  );
  history.push(snapshot);
}

function resetGrid() {
  initGrid();
}

function getNeighbors(x, y) {
  let neighbors = [];
  for (let dy = -1; dy <= 1; dy++) {
    for (let dx = -1; dx <= 1; dx++) {
      if (dx === 0 && dy === 0) continue;
      let nx = x + dx;
      let ny = y + dy;
      if (nx >= 0 && nx < cols && ny >= 0 && ny < rows) {
        neighbors.push(grid[ny][nx]);
      }
    }
  }
  return neighbors;
}

function colorForStress(stress, broken, willBreak, damage, maxVisualStress) {
  if (broken) return color(0);
  if (willBreak) return color(0, 255, 255);
  if (stress === 0 || maxVisualStress === 0) return color(255);

  let t = stress / maxVisualStress;
  let baseColor;
  if (t < 0.4) {
    baseColor = lerpColor(color(255), color(255, 255, 0), t / 0.4);
  } else if (t < 0.8) {
    baseColor = lerpColor(color(255, 255, 0), color(255, 165, 0), (t - 0.4) / 0.4);
  } else {
    baseColor = lerpColor(color(255, 165, 0), color(255, 0, 0), (t - 0.8) / 0.2);
  }

  // Подмешаем фиолетовый в зависимости от damage
  if (damage > 0 && damage < 1) {
    return lerpColor(baseColor, color(128, 0, 128), damage);
  }
  return baseColor;
}